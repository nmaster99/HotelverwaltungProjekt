package ch.bbw.model.bo;

import java.sql.Date;
import java.util.List;

public class Booking extends Bo{
	
	private Integer id;
	private Date arrivalDate;
	private Date departurDate;
	private List<Position> positions;
	
	public Booking(){
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getDeparturDate() {
		return departurDate;
	}

	public void setDeparturDate(Date departurDate) {
		this.departurDate = departurDate;
	}

	public List<Position> getPositions() {
		return positions;
	}

	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}
	
	
	
}
