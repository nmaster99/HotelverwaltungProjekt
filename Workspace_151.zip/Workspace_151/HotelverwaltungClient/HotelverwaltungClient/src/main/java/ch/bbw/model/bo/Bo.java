package ch.bbw.model.bo;

import ch.bbw.model.id.IdType;

public class Bo extends IdType{

}
