package ch.bbw.guimanager;

import java.util.List;

import ch.bbw.model.bo.Person;

public class PersonControllerBean implements IGuiManager{

	private String inputName;
	private List<Person> selectedPersons;
	
	

	public String getInputName() {
		return inputName;
	}

	public void setInputName(String inputName) {
		this.inputName = inputName;
	}
	

	public List<Person> getSelectedPersons() {
		return selectedPersons;
	}

	
	public void setSelectedPersons(List<Person> selectedPersons) {
		this.selectedPersons = selectedPersons;
	}
	
	
}
