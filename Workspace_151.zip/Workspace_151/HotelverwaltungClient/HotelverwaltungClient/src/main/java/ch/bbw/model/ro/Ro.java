package ch.bbw.model.ro;

import ch.bbw.model.id.IdType;

public class Ro extends IdType{

}
