package ch.bbw.guimanager;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.List;

import ch.bbw.hotelverwaltung.rmi.IHotelverwaltung;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;

public class UserControllerBean implements IGuiManager {

	private UserRo selectedUser;
	private List<UserRo> userList;
	private List<Position> positionList;
	
	
	
	public List<Position> getPositionList(){
		IHotelverwaltung hv;
		try {
			hv = (IHotelverwaltung) Naming.lookup("rmi://127.0.0.1/Hotelverwaltung");
			
			positionList = hv.getPositionsByUserId(selectedUser.getId());
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return positionList;
	}
	
	public List<UserRo> getUserList(){
		try {
			IHotelverwaltung hv = (IHotelverwaltung) Naming.lookup("rmi://127.0.0.1/Hotelverwaltung");
			
			userList = hv.getUsers();
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return userList;
	}

	public UserRo getSelectedUser() {
		return selectedUser;
	}

	public void setSelectedUser(UserRo selectedUser) {
		this.selectedUser = selectedUser;
	}
	
	
}
