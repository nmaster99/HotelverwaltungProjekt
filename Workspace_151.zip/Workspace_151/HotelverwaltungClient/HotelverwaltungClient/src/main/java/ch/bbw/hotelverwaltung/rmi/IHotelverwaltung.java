package ch.bbw.hotelverwaltung.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;



public interface IHotelverwaltung extends Remote{
	
	/*
	 * Gibt Liste aller Mitarbeiter zurr�ck
	 */
	public List<UserRo> getUsers() throws RemoteException; 
	
	/*
	 * L�dt alle K�ufe unter dieser Person
	 */
	 public List<Position> getPositionsByUserId(Integer id) throws RemoteException;
	
	
	/*
	 * Total des jeweiligen Kaufes
	 */
	 public Double getTotalOfPositionByPositionId(Integer id) throws RemoteException;
	
	/*
	 * Filtern der Personen mit Name
	 */
	public List<Person> getPersonsByName(String name) throws RemoteException;
	
	/*
	 * Get Persons
	 */
	 public List<Person> getPersons() throws RemoteException;
	
	
	/*
	 * Get Bookings of a Person by id
	 */
	public List<Booking> getPersonBookingsByUserId(Integer id) throws RemoteException;
}
