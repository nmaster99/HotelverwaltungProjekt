package ch.bbw.hotelverwaltung.rmi;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

import ch.bbw.model.ro.UserRo;

public class Client {
	
	private Client(){
	}
	
	public static void main(String args[]) {
		
		
		try{
			IHotelverwaltung hv = (IHotelverwaltung) Naming.lookup("rmi://127.0.0.1/Hotelverwaltung");
			
			List<UserRo> users = hv.getUsers();
			
			if(users.isEmpty()){
				System.out.println("Error: Unsuccessfull, the List is empty!");
			} else if (!users.isEmpty()){
				System.out.println("Success! List is filled with Objects!");
			}
			
			for(UserRo user : users){
				System.out.println(user.getName());
			}
			
			//testen der getTotal... Funktion f�r User Id 4
			System.out.println("User: 4 Total: "+hv.getTotalOfPositionByPositionId(4));
			
		} catch(Exception e){
			System.out.println(e.getMessage());
		}
    }  
}
