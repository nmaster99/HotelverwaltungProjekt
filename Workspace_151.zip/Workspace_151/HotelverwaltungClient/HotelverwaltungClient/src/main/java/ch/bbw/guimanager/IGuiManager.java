package ch.bbw.guimanager;

public interface IGuiManager {

}
