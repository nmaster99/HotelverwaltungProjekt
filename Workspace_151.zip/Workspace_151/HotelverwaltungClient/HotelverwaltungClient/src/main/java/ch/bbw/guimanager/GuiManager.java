package ch.bbw.guimanager;

public class GuiManager {

}
