package ch.bbw.model.id;

public class IdType {
	
	private Integer id;
	
}
