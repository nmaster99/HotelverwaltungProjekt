package ch.bbw.personmanager;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;

public interface IPersonManager {
	
	/*
	 * Filtern der Personen mit Name
	 */
	public List<Person> getPersonsByName(String name);
	
	/*
	 * Get Persons
	 */
	public List<Person> getPersons();
	
	
	/*
	 * Get Bookings of a Person by id
	 */
	public List<Booking> getPersonBookingsByUserId(Integer id);
	
}
