package ch.bbw.technicalexceptions;


public class DBConnectException extends TechnicalException
{
   /**
	 * 
	 */
   private static final long serialVersionUID = 1L;

   public DBConnectException()
   {
      super();
   }

   public DBConnectException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBConnectException(String message)
   {
      super(message);
   }

   public DBConnectException(Throwable cause)
   {
      super(cause);
   }
}
