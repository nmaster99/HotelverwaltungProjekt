package ch.bbw;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;
import ch.bbw.processmanager.ProcessManagerDelegator;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	/*
    	 * Test getUsers()
    	 */
    	System.out.println("************************************");
    	System.out.println("**********Test getUsers()***********");
    	System.out.println("************************************");
    	
    	List<UserRo> users = null;
    	users = ProcessManagerDelegator.getInstance().getUsers();
    	
    	for(UserRo user : users){
    		System.out.println(user.getId() + " " + user.getName());
    	}
    	
    	/*
    	 * Test getPositionsByUserId()
    	 */
    	System.out.println("************************************");
    	System.out.println("****Test getPositionsByUserId()*****");
    	System.out.println("************************************");
    	
    	List<Position> positions = null;
    	positions = ProcessManagerDelegator.getInstance().getPositionsByUserId(1);
    	
    	for(Position position : positions){
    		System.out.println(position.getId() + ": " + position.getQuantity() + "/" + position.getPrice() + "/" + position.getDiscount() + 
    				"/" + position.getDate());
    	}
    	System.out.println("Total : " + ProcessManagerDelegator.getInstance().getTotalOfPositionByPositionId(1));
    	
    	
    	/*
    	 * Test getPersonByName()
    	 */
    	System.out.println("************************************");
    	System.out.println("****Test getPersonByName()*****");
    	System.out.println("************************************");
    	int i = 1;
    	
    	for(Person person : ProcessManagerDelegator.getInstance().getPersonsByName("Opitz")){
    		System.out.println(i + ": " + person.getFirstName() + " " + person.getLastName());
    	}
    	
    	/*
    	 * Test getPersons()
    	 */
    	System.out.println("************************************");
    	System.out.println("****Test getPersons()*****");
    	System.out.println("************************************");
    	int y = 1;
    	
    	for(Person person : ProcessManagerDelegator.getInstance().getPersons()){
    		System.out.println(y + ": " + person.getFirstName() + " " + person.getLastName());
    		y++;
    	}
    	
    	/*
    	 * Test getPersonBookingsByUserId()
    	 */
    	System.out.println("************************************");
    	System.out.println("****Test getPersonBookingsByUserId()*****");
    	System.out.println("************************************");
    	System.out.println(" Bookings for Person with ID -> 5 ");

    	for(Booking booking : ProcessManagerDelegator.getInstance().getPersonBookingsByUserId(5)){
    		System.out.println("Booking ID:" + booking.getId() + " Arrival:" + booking.getArrivalDate() + " Departure:" + booking.getDeparturDate());
    		System.out.println();
    		for(Position position : booking.getPositions()){
    			System.out.println("    Id:" + position.getId() +" Service Type: "+position.getServiceType()+ " Quantity:" + position.getQuantity() + " Price:" + position.getPrice());
    		}
    	}
    	
    }
}
