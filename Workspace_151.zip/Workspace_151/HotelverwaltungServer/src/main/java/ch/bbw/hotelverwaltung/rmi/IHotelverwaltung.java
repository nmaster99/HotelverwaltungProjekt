package ch.bbw.hotelverwaltung.rmi;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

import ch.bbw.model.bo.Position;
import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.ro.UserRo;



public interface IHotelverwaltung extends Remote{

	/*
	 * Gibt Liste aller Mitarbeiter zurrück
	 */
	List<UserRo> getUsers() throws RemoteException; 
	
	/*
	 * Lädt alle Käufe unter dieser Person
	 */
	 List<Position> getPositionsByUserId(Integer id) throws RemoteException;
	
	
	/*
	 * Total des jeweiligen Kaufes
	 */
	 Double getTotalOfPositionByPositionId(Integer id) throws RemoteException;
	
	/*
	 * Filtern der Personen mit Name
	 */
	List<Person> getPersonsByName(String name) throws RemoteException;
	
	/*
	 * Get Persons
	 */
	 List<Person> getPersons() throws RemoteException;
	
	
	/*
	 * Get Bookings of a Person by id
	 */
	List<Booking> getPersonBookingsByUserId(Integer id) throws RemoteException;
	
}

