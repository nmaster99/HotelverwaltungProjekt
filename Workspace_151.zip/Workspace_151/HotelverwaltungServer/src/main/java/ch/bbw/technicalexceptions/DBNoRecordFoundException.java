package ch.bbw.technicalexceptions;

public class DBNoRecordFoundException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBNoRecordFoundException()
   {
      super();
   }

   public DBNoRecordFoundException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBNoRecordFoundException(String message)
   {
      super(message);
   }

   public DBNoRecordFoundException(Throwable cause)
   {
      super(cause);
   }
}
