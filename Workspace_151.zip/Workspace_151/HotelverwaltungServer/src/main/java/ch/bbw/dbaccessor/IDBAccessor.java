package ch.bbw.dbaccessor;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;

public interface IDBAccessor {
	
	/*
	 * Gibt Liste aller Mitarbeiter zurrück
	 */
	public List<UserRo> getUsers(); 
	
	/*
	 * Lädt alle Käufe unter dieser Person
	 */
	public List<Position> getPositionsByUserId(Integer id);
	
	/*
	 * Filtern der Personen mit Name
	 */
	public List<Person> getPersonsByName(String name);
	
	/*
	 * Get Persons
	 */
	public List<Person> getPersons();
	
	
	/*
	 * Get Bookings of a Person by id
	 */
	public List<Booking> getPersonBookingsByUserId(Integer id);
	
}
