package ch.bbw.hotelverwaltung.rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;
import ch.bbw.processmanager.ProcessManagerDelegator;

public class Hotelverwaltung extends UnicastRemoteObject implements IHotelverwaltung{

	public static void main(String[] args) {
        init();
    }
	
	private static void init(){
		
		try{
			LocateRegistry.createRegistry(1099);
		} catch (RemoteException e){
			System.out.println("Error: "+e.getMessage());
		}
		try{
			Hotelverwaltung hv = new Hotelverwaltung();
			Naming.rebind("//localhost/Hotelverwaltung", hv);
			System.out.println("Registry added succesfully!");
		} catch (RemoteException e){
			System.out.println("Error: " + e.getMessage());
		} catch (MalformedURLException e){
			System.out.println("Error: " + e.getMessage());
		}
	}
	
	protected Hotelverwaltung() throws RemoteException{
		super();
	}
	
	public List<UserRo> getUsers() throws RemoteException {
		// TODO Auto-generated method stub
		return ProcessManagerDelegator.getInstance().getUsers();
	}

	public List<Position> getPositionsByUserId(Integer id)
			throws RemoteException {
		// TODO Auto-generated method stub
		return ProcessManagerDelegator.getInstance().getPositionsByUserId(id);
	}

	public Double getTotalOfPositionByPositionId(Integer id)
			throws RemoteException {
		// TODO Auto-generated method stub
		return ProcessManagerDelegator.getInstance().getTotalOfPositionByPositionId(id);
		
	}

	public List<Person> getPersonsByName(String name) throws RemoteException {
		// TODO Auto-generated method stub
		return ProcessManagerDelegator.getInstance().getPersonsByName(name);
	}

	public List<Person> getPersons() throws RemoteException {
		// TODO Auto-generated method stub
		return ProcessManagerDelegator.getInstance().getPersons();
	}

	public List<Booking> getPersonBookingsByUserId(Integer id)
			throws RemoteException {
		// TODO Auto-generated method stub
		return ProcessManagerDelegator.getInstance().getPersonBookingsByUserId(id);
	}

	public String getTestMessage() throws RemoteException {
		// TODO Auto-generated method stub
		return "Test Message delivered";
	}
	
	
}
