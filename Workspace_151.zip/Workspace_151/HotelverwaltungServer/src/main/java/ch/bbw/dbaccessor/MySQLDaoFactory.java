package ch.bbw.dbaccessor;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


import ch.bbw.technicalexceptions.DBConnectException;

class MySQLDaoFactory {
	private static Connection myConnection = null;
	   private static MySQLDaoFactory factoryInstance = new MySQLDaoFactory();

	   private MySQLDaoFactory()
	   {
	   }

	   static public MySQLDaoFactory getInstance()
	   {
	      return factoryInstance;
	   }

	   public static Connection createConnection() throws DBConnectException
	   {
	      synchronized (MySQLDaoFactory.class)
	      {
	         try
	         {
	        	 String driver = "com.mysql.jdbc.Driver";
	        	  String connection = "jdbc:mysql://localhost:3306/hotel";
	        	  String user = "root";
	        	  String password = "";
	        	  Class.forName(driver);
	        	  Connection myConnection = DriverManager.getConnection(connection, user, password);
	        	  
	        	  return myConnection;
	         }
	         catch (Exception de)
	         {
	            de.printStackTrace();
	            DBLogger.log("Have problems to connect datasource " + "jdbc:mysql://localhost:3306/hotel", de);
	            throw new DBConnectException(de.getMessage());
	         }
	      }
	     // System.out.println("Connection successfull")	     
	   }

	public MySQLUserDao getUserDao() {
		
		return new MySQLUserDao();
	}
	
	public MySQLPersonDao getPersonDao(){
		
		return new MySQLPersonDao();
	}

}
