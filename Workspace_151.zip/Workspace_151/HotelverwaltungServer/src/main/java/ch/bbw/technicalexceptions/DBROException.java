package ch.bbw.technicalexceptions;

public class DBROException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBROException()
   {
      super();
   }

   public DBROException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBROException(String message)
   {
      super(message);
   }

   public DBROException(Throwable cause)
   {
      super(cause);
   }

}
