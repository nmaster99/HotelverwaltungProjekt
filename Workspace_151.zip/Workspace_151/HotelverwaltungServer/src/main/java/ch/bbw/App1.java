package ch.bbw;

import java.util.List;

import ch.bbw.model.bo.Position;
import ch.bbw.processmanager.ProcessManagerDelegator;

public class App1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
    	 * Test getPositionsByUserId()
    	 */
    	System.out.println("************************************");
    	System.out.println("****Test getPositionsByUserId()*****");
    	System.out.println("************************************");
    	
    	List<Position> positions = null;
    	positions = ProcessManagerDelegator.getInstance().getPositionsByUserId(1);
    	
    	for(Position position : positions){
    		System.out.println(position.getId() + ": " + position.getQuantity() + "/" + position.getPrice() + "/" + position.getDiscount() + 
    				"/" + position.getDate());
    	}
    	System.out.println("Total : " + ProcessManagerDelegator.getInstance().getTotalOfPositionByPositionId(1));
    	

	}

}
