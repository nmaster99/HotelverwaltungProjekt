package ch.bbw.processmanager;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;
import ch.bbw.personmanager.PersonManagerDelegator;
import ch.bbw.usermanager.UserManagerDelegator;

public class ProcessManager implements IProcessManager{

	
	public List<UserRo> getUsers() {
		// TODO Auto-generated method stub
		return UserManagerDelegator.getInstance().getUsers();
	}

	public List<Position> getPositionsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return UserManagerDelegator.getInstance().getPositionsByUserId(id);
	}

	public Double getTotalOfPositionByPositionId(Integer id) {
		// TODO Auto-generated method stub
		return UserManagerDelegator.getInstance().getTotalOfPositionByPositionId(id);
	}

	
	public List<Person> getPersonsByName(String name) {
		return PersonManagerDelegator.getInstance().getPersonsByName(name);
	}

	public List<Person> getPersons() {
		// TODO Auto-generated method stub
		return PersonManagerDelegator.getInstance().getPersons();
	}

	public List<Booking> getPersonBookingsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return PersonManagerDelegator.getInstance().getPersonBookingsByUserId(id);
	}

}
