package ch.bbw.processmanager;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;

public class ProcessManagerDelegator implements IProcessManager {
	
	private static ProcessManagerDelegator instance;
	private ProcessManager processManager;
	
	private ProcessManagerDelegator() {
		processManager = new ProcessManager();
	}

	public static IProcessManager getInstance() {
		if (instance == null) {
			instance = new ProcessManagerDelegator();
		}
		return instance;
	}


	public List<UserRo> getUsers() {
		// TODO Auto-generated method stub
		return processManager.getUsers();
		
	}

	public List<Position> getPositionsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return processManager.getPositionsByUserId(id);
	
	}

	public Double getTotalOfPositionByPositionId(Integer id) {
		// TODO Auto-generated method stub
		return processManager.getTotalOfPositionByPositionId(id);
	}
	

	public List<Person> getPersonsByName(String name) {
		// TODO Auto-generated method stub
		return processManager.getPersonsByName(name);
	}
	
	public List<Person> getPersons() {
		// TODO Auto-generated method stub
		return processManager.getPersons();
	}

	public List<Booking> getPersonBookingsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return processManager.getPersonBookingsByUserId(id);
	}
}
