package ch.bbw.technicalexceptions;

public class DBInsertException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBInsertException()
   {
      super();
   }

   public DBInsertException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBInsertException(String message)
   {
      super(message);
   }

   public DBInsertException(Throwable cause)
   {
      super(cause);
   }

}
