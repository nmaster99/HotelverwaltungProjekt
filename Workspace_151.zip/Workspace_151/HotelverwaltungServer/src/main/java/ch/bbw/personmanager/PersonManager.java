package ch.bbw.personmanager;

import java.util.List;

import com.mysql.jdbc.MySQLConnection;

import ch.bbw.dbaccessor.DBAccessDelegator;
import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;

public class PersonManager implements IPersonManager{

	public List<Person> getPersonsByName(String name) {
		// TODO Auto-generated method stub
		return DBAccessDelegator.getInstance().getPersonsByName(name);
	}

	public List<Person> getPersons() {
		// TODO Auto-generated method stub
		return DBAccessDelegator.getInstance().getPersons();
	}

	public List<Booking> getPersonBookingsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return DBAccessDelegator.getInstance().getPersonBookingsByUserId(id);
	}

}
