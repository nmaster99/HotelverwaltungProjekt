package ch.bbw.dbaccessor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.fabric.xmlrpc.base.Data;
import com.mysql.jdbc.AbandonedConnectionCleanupThread;

import ch.bbw.dbaccessor.dos.BookingDo;
import ch.bbw.dbaccessor.dos.PersonDo;
import ch.bbw.dbaccessor.dos.PositionDo;
import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.technicalexceptions.DBConnectException;

public class MySQLPersonDao implements IPersonDao {

	public List<Person> getPersonsByName(String name) {
		System.out.println("Successfull (Last appropriate Layer (DB))");
		List<Person> persons = new ArrayList<Person>();
		ResultSet rs = null;
		
		try{
			PersonDo personDo = new PersonDo();
			Person person = new Person();
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetPersonsByNameStatement(name);
			
			rs = new DatabaseRetriever().retrieve(query);
			while(rs.next()){
				
				personDo = DatabaseConverter.convertPersonResultSetToDo(rs);
				person = DatabaseConverter.convertPersonDoToBo(personDo);
				persons.add(person);
			}
			
		} catch(DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return persons;
	}

	public List<Person> getPersons() {
		System.out.println("Successfull (Last appropriate Layer (DB))");
		List<Person> persons = new ArrayList<Person>();
		ResultSet rs = null;
		
		try{
			PersonDo personDo = new PersonDo();
			Person person = new Person();
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetPersonsStatement();
			
			rs = new DatabaseRetriever().retrieve(query);
			while(rs.next()){
				
				personDo = DatabaseConverter.convertPersonResultSetToDo(rs);
				person = DatabaseConverter.convertPersonDoToBo(personDo);
				persons.add(person);
			}
			
		} catch(DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return persons;
	}

	public List<Booking> getPersonBookingsByUserId(Integer id) {
		System.out.println("Successfull (Last appropriate Layer (DB))");
		List<Booking> bookings = new ArrayList<Booking>();
		ResultSet rs = null;
		
		try{
			BookingDo bookingDo = new BookingDo();
			Booking booking = new Booking();
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetPersonBookingsByUserIdStatement(id);
			
			rs = new DatabaseRetriever().retrieve(query);
			while(rs.next()){
				
				bookingDo = DatabaseConverter.convertBookingResultSetToDo(rs);
				booking = DatabaseConverter.convertBookingDoToBo(bookingDo);
				booking.setPositions(getPositionsByBookingId(booking.getId()));
				
				bookings.add(booking);
			}
			
		} catch(DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return bookings;
	}
	
	public List<Position> getPositionsByBookingId(Integer id){
		
		List<Position> positions = new ArrayList<Position>();
		ResultSet rs = null;
		
		try{
			PositionDo positionDo = new PositionDo();
			Position position = new Position();
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetPositionsByBookingId(id);
			
			rs = new DatabaseRetriever().retrieve(query);
			while(rs.next()){
				
				positionDo = DatabaseConverter.convertPositionResultSetToDo(rs);
				position = DatabaseConverter.convertPositionDoToBo(positionDo);
				position.setServiceType(getServiceTypeById(positionDo.getService_idfs()));
				positions.add(position);
			}
			
		} catch(DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return positions;
	}
	
	public String getServiceTypeById(Integer id){
		String serviceType = new String();
		ResultSet rs = null;
		
		try{
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetServiceTypeById(id);
			rs = new DatabaseRetriever().retrieve(query);
			if(rs.next()){
				serviceType = rs.getString("Beschreibung");
			}
			
		} catch(DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return serviceType;
	}
}
