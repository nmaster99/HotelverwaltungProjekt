package ch.bbw.dbaccessor;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import ch.bbw.dbaccessor.*;


public class DatabaseRetriever {
	Connection myConnection = null;
	
	/**
	 * @throws ch.bbw.technicalexceptions.DBConnectException 
	 * 
	 */
	   public ResultSet retrieve(String aSQLQueryString) throws SQLException, ch.bbw.technicalexceptions.DBConnectException
	   {
	      ResultSet result = null;
	      PreparedStatement prepStatement = null;

	      myConnection = DatabaseConnection.getConnection();
	      if (myConnection == null)
	         myConnection = MySQLDaoFactory.createConnection();

		      if (myConnection != null)
		      {
		         prepStatement = myConnection.prepareStatement(aSQLQueryString);
		         result = prepStatement.executeQuery();
		      }
	      return result;
	   }
	}
