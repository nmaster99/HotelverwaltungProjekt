package ch.bbw.technicalexceptions;

public class DBReadException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBReadException()
   {
      super();
   }

   public DBReadException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBReadException(String message)
   {
      super(message);
   }

   public DBReadException(Throwable cause)
   {
      super(cause);
   }

}
