package ch.bbw.technicalexceptions;


public class DBConfigReadException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBConfigReadException()
   {
      super();
   }

   public DBConfigReadException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBConfigReadException(String message)
   {
      super(message);
   }

   public DBConfigReadException(Throwable cause)
   {
      super(cause);
   }
}
