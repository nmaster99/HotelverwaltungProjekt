package ch.bbw.usermanager;

import java.util.List;

import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;
import ch.bbw.processmanager.IProcessManager;
import ch.bbw.processmanager.ProcessManager;
import ch.bbw.processmanager.ProcessManagerDelegator;

public class UserManagerDelegator implements IUserManager{
	
	private static UserManagerDelegator instance;
	private UserManager userManager;
	
	private UserManagerDelegator() {
		userManager = new UserManager();
	}

	public static IUserManager getInstance() {
		if (instance == null) {
			instance = new UserManagerDelegator();
		}
		return instance;
	}

	public List<UserRo> getUsers() {
		// TODO Auto-generated method stub
		return userManager.getUsers();
	}

	public List<Position> getPositionsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return userManager.getPositionsByUserId(id);
	}

	public Double getTotalOfPositionByPositionId(Integer id) {
		// TODO Auto-generated method stub
		return userManager.getTotalOfPositionByPositionId(id);
	}
}
