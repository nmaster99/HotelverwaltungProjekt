package ch.bbw.technicalexceptions;


public class DBLoginTryException extends TechnicalException
{

   private static final long serialVersionUID = 1L;

   public DBLoginTryException()
   {
      super();
   }

   public DBLoginTryException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBLoginTryException(String message)
   {
      super(message);
   }

   public DBLoginTryException(Throwable cause)
   {
      super(cause);
   }

}
