/**
 * 
 */
package ch.bbw.dbaccessor;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import ch.bbw.technicalexceptions.DBCommitException;
import ch.bbw.technicalexceptions.DBConnectException;
import ch.bbw.technicalexceptions.DBDriverException;
import ch.bbw.technicalexceptions.DBRollbackException;
import ch.bbw.technicalexceptions.TechnicalException;

/**
 * @author FC076953
 * 
 */
public class DatabaseConnection
{
   private static String vcid = "DatabaseConnection - Version 1.0";

   /**
    * Driver object name to use for JDBC connection
    */
   private String myDatabaseDriver;

   /**
    * URL to use when connecting via the given driver
    */
   private String myConnectionString;

   /**
    * Description of this connection
    */
   private String myDescription;

   /**
    * Is this connection object actually connected to the database yet?
    */
   private boolean myIsConnected = false;

   /**
    * JDBC connection object
    */
   private static Connection myConnection;

   /**
    * Parameter to connect to the database
    */
   private Properties myProperties;

   /**
    * When was this connection last used?
    */
   private long myLastUsed;

   // no default constructor
   @SuppressWarnings("unused")
   private DatabaseConnection()
   {
   }

   public DatabaseConnection(String aDatabaseDriver, String aConnectionString) throws TechnicalException
   {
      this(aDatabaseDriver, aConnectionString, "no description");
   }

   public DatabaseConnection(String aDatabaseDriver, String aConnectionString, String aDescription) throws TechnicalException
   {

      myDatabaseDriver = aDatabaseDriver;
      myConnectionString = aConnectionString;
      myDescription = aDescription;

      try
      {
         Class.forName(myDatabaseDriver).newInstance();
      }
      catch (Exception se)
      {
         System.out.println(se);

         se.printStackTrace();
         throw new DBDriverException("Can't load Database Driver " + myDatabaseDriver);
      }
      myConnection = null;
      myIsConnected = false;
      used();
   }

   public boolean isConnected()
   {
      return myIsConnected;
   }

   public long getLastUsed()
   {
      return myLastUsed;
   }

   private void used()
   {
      myLastUsed = System.currentTimeMillis();
   }

   public synchronized void setDescription(String newDescription)
   {
      if (newDescription != null)
         myDescription = newDescription;
      used();
   }

   public String getDescription()
   {
      return myDescription;
   }

   public String getConnectionString()
   {
      return myConnectionString;
   }

   public static Connection getConnection()
   {
      return myConnection;
   }

   public String getLogin()
   {
      return myProperties.getProperty("user");
   }

   public String getPassword()
   {
      return myProperties.getProperty("password");
   }

   public String getDatabaseDriver()
   {
      return myDatabaseDriver;
   }

   public synchronized void connect(String aLogin, String aPassword) throws TechnicalException
   {

      Properties theProperties = new Properties();
      theProperties.put("user", aLogin);
      theProperties.put("password", aPassword);
      theProperties.put("autoReconnect", "true");
      connect();
   }

   public synchronized void connect() throws TechnicalException
   {
      if (myConnection != null)
      {
         try
         {
            disconnect();
         }
         catch (TechnicalException e)
         {
         }
      }
      try
      {
         myConnection = DriverManager.getConnection(myConnectionString);
         if (myConnection == null)
         {
            throw new DBConnectException("Can't get connection to database via driver '" + myDatabaseDriver + "' and server " + myConnectionString + "JDBC returned a null connection. (" + myDescription + ")");
         }
         setAutoCommit(false);

      }
      catch (SQLException se)
      {
         System.out.println(se);

         se.printStackTrace();
         if (myConnection != null)
            try
            {
               myConnection.close();
            }
            catch (SQLException sql)
            {
            }
         myConnection = null;
         throw new DBConnectException("Can't get connection to database via driver '" + myDatabaseDriver + "' and server " + myConnectionString + "' (" + myDescription + ") \n" + se.getMessage());
      }
      myIsConnected = true;
      used();
   }

   /** @modelguid {FE2321BD-BE74-4AF4-B3D8-BEEA26633FC2} */
   public synchronized void disconnect() throws TechnicalException
   {
      try
      {
         if (myConnection != null)
            myConnection.close();
      }
      catch (SQLException se)
      {
         /*
          * throw new DatabaseException( "Can't disconnect to database via driver '" + myDatabaseDriver + "' and server " + myConnectionString + "JDBC returned a null connection. (" + myDescription + ") \n" + se.getMessage());
          */
      }
      finally
      {
         myConnection = null;
         myIsConnected = false;
         used();
      }

   }

   // $ANALYSIS-IGNORE
   public void finalize()
   {
      if (isConnected())
         try
         {
            disconnect();
         }
         catch (TechnicalException de)
         {
            de.printStackTrace();
         }
      // return;
   }

   public synchronized boolean begin() throws TechnicalException
   {
      return isConnected();
   }

   public synchronized void commit() throws TechnicalException
   {
      if (!isConnected())
         return;

      try
      {
         myConnection.commit();
      }
      catch (SQLException se)
      {
         throw new DBCommitException("Could not commit (" + myDescription + ") \n" + se.getMessage());
      }
      used();
   }

   public synchronized void rollback() throws TechnicalException
   {
      if (!isConnected())
         return;
      try
      {
         myConnection.rollback();
      }
      catch (SQLException se)
      {
         throw new DBRollbackException("Could not rollback (" + myDescription + ") \n" + se.getMessage());
      }
      used();
   }

   public String nativeSQL(String sql) throws SQLException
   {
      if (isConnected())
         return myConnection.nativeSQL(sql);
      else
         return null;
   }

   public Statement createStatement() throws SQLException
   {
      if (isConnected())
         return myConnection.createStatement();
      else
         return null;
   }

   public CallableStatement prepareCall(String sql) throws SQLException
   {
      if (isConnected())
         return myConnection.prepareCall(sql);
      else
         return null;
   }

   public PreparedStatement prepareStatement(String sql) throws SQLException
   {
      if (isConnected())
         return myConnection.prepareStatement(sql);
      else
         return null;
   }

   public synchronized void setAutoCommit(boolean autoCommit) throws SQLException
   {
      if (isConnected())
         myConnection.setAutoCommit(autoCommit);
   }

   public synchronized boolean getAutoCommit() throws SQLException
   {
      if (isConnected())
         return myConnection.getAutoCommit();
      else
         return false;
   }

} // end of class
