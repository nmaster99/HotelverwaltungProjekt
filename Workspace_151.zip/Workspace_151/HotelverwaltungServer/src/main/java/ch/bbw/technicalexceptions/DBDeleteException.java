package ch.bbw.technicalexceptions;

public class DBDeleteException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBDeleteException()
   {
      super();
   }

   public DBDeleteException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBDeleteException(String message)
   {
      super(message);
   }

   public DBDeleteException(Throwable cause)
   {
      super(cause);
   }
}
