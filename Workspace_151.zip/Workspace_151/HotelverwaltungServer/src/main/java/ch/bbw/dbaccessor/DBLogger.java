package ch.bbw.dbaccessor;

/**
 * <!-- begin-user-doc --> <!-- end-user-doc -->
 * 
 * @author FC076953
 * 
 * @uml.annotations derived_abstraction="platform:/resource/OrganizerModel/componentModel.emx#_v-lE3sgbEdySXYP8_UuePw"
 * @!generated "sourceid:platform:/resource/OrganizerModel/componentModel.emx#_v-lE3sgbEdySXYP8_UuePw"
 */
class DBLogger
{
   // this class might be replaced with log4j.
   // just quick and dirty write into files
   // change this for log to a file not console

   public static void log(String aString)
   {
      System.out.println(aString);
   }

   public static void log(String aString, Exception e)
   {
      // write the stuff into a file
      aString += aString + "\n" + e.toString();
      log(aString);
   }
}
