package ch.bbw.technicalexceptions;

public class DBConversionException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBConversionException()
   {
      super();
   }

   public DBConversionException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBConversionException(String message)
   {
      super(message);
   }

   public DBConversionException(Throwable cause)
   {
      super(cause);
   }

}
