package ch.bbw.dbaccessor;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;

public class DBAccessDelegator implements IDBAccessor{
	
private static IDBAccessor instance = null;
	
	private DBAccessDelegator() {
    }

    public static IDBAccessor getInstance() {
		if (instance == null) {
		    instance = new DBAccessDelegator();
		}
		return instance;
    }

	public List<UserRo> getUsers() {
		// TODO Auto-generated method stub
		return MySQLDaoFactory.getInstance().getUserDao().getUsers();
	}

	public List<Position> getPositionsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return MySQLDaoFactory.getInstance().getUserDao().getPositionsByUserId(id);
	}

	public List<Person> getPersonsByName(String name) {
		// TODO Auto-generated method stub
		return MySQLDaoFactory.getInstance().getPersonDao().getPersonsByName(name);
	}

	public List<Person> getPersons() {
		// TODO Auto-generated method stub
		return MySQLDaoFactory.getInstance().getPersonDao().getPersons();
	}

	public List<Booking> getPersonBookingsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return MySQLDaoFactory.getInstance().getPersonDao().getPersonBookingsByUserId(id);
	}

}
