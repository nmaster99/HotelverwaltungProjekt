package ch.bbw.dbaccessor;

import ch.bbw.dbaccessor.dos.Do;


public class DatabaseHelper {
	
	private String sqlString;

	/*
	 * Gibt einen SQL-String zurück um die GetUsers Daten zu hohlen
	 */
	public String createGetUsersSQLStatement() {
		sqlString = null;
		sqlString = ("SELECT * FROM benutzer;");

		return sqlString;
	}
	
	/*
	 * Gibt einen SQL-String zurück um die GetPositionsByUserId Daten zu hohlen
	*/ 
	public String createGetPositionsByUserIdSQLStatement(Integer userId) {
		sqlString = null;
		sqlString = ("SELECT * FROM position WHERE Benutzer_IDFS = " + userId.toString() + ";");

		return sqlString;
	}
	
	/*
	 * Gibt einen SQL-String zurück um die getPersonByName Daten zu hohlen
	*/ 
	public String createGetPersonsByNameStatement(String name){
		sqlString = null;
		sqlString = ("SELECT * FROM person WHERE Name ='"+name+"';");
		
		return sqlString;
	}
	
	/*
	 * Gibt einen SQL-String zurück um die getPersons Daten zu hohlen
	*/ 
	public String createGetPersonsStatement(){
		sqlString = null;
		sqlString = ("SELECT * FROM person;");
		
		return sqlString;
	}
	
	/*
	 * Gibt einen SQL-String zurück um die getPersons Daten zu hohlen
	*/ 
	public String createGetPersonBookingsByUserIdStatement(Integer id){
		sqlString = null;
		sqlString = ("SELECT * FROM buchung WHERE Buchung_ID = " + id +";");
		
		return sqlString;
	}
	
	public String createGetPositionsByBookingId(Integer id){
		sqlString = null;
		sqlString = ("SELECT * FROM position WHERE Buchung_IDFS = " + id + ";");
		return sqlString;
	}
	
	public String createGetServiceTypeById(Integer id){
		sqlString = null;
		sqlString = ("SELECT * FROM leistung WHERE Leistung_ID = " + id +";");
		return sqlString;
		
	}
	
}
