package ch.bbw.dbaccessor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import ch.bbw.dbaccessor.dos.PositionDo;
import ch.bbw.dbaccessor.dos.UserRoDo;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;
import ch.bbw.technicalexceptions.DBConnectException;

public class MySQLUserDao implements IUserDao{
	
	public List<UserRo> getUsers() {

		System.out.println("Successfull (Last appropriate Layer (DB))");
		List<UserRo> users = new ArrayList<UserRo>();
		ResultSet rs = null;
		
		try {
			UserRoDo userRoDo = new UserRoDo();
			UserRo userRo = new UserRo();
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetUsersSQLStatement();
			
			rs = new DatabaseRetriever().retrieve(query);
			while(rs.next()){
				
				userRoDo = DatabaseConverter.convertUserResultSetToDo(rs);
				userRo = DatabaseConverter.convertUserDoToRo(userRoDo);
				users.add(userRo);
			}
		
			rs.close();
		
		} catch (DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return users;
	}

	public List<Position> getPositionsByUserId(Integer userId) {
		
		System.out.println("Successfull (Last appropriate Layer (DB))");
		List<Position> positions = new ArrayList<Position>();
		ResultSet rs = null;
		
		try{
			PositionDo positionDo = new PositionDo();
			Position position = new Position();
			DatabaseHelper dbHelper = new DatabaseHelper();
			String query = dbHelper.createGetPositionsByUserIdSQLStatement(userId);
			
			rs = new DatabaseRetriever().retrieve(query);
			while(rs.next()){
				
				positionDo = DatabaseConverter.convertPositionResultSetToDo(rs);
				position = DatabaseConverter.convertPositionDoToBo(positionDo);
				position.setServiceType(getServiceTypeById(positionDo.getBooking_idfs()));
				positions.add(position);
			}
			rs.close();
			
		} catch (DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return positions;
	}
	
	public String getServiceTypeById(Integer id){
		String serviceType = new String();
		ResultSet rs = null;
		
		try{
			DatabaseHelper dbHelper = new DatabaseHelper();
			
			String query = dbHelper.createGetServiceTypeById(id);
			rs = new DatabaseRetriever().retrieve(query);
			if(rs.next()){
				serviceType = rs.getString("Beschreibung");
			}
			
		} catch(DBConnectException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return serviceType;
	}

}
