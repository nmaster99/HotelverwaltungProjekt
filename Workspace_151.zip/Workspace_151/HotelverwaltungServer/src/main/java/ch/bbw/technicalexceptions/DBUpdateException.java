package ch.bbw.technicalexceptions;

public class DBUpdateException extends TechnicalException
{
   private static final long serialVersionUID = 1l;

   public DBUpdateException()
   {
      super();
   }

   public DBUpdateException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBUpdateException(String message)
   {
      super(message);
   }

   public DBUpdateException(Throwable cause)
   {
      super(cause);
   }
}
