package ch.bbw.technicalexceptions;

public class DBRollbackException extends TechnicalException
{
   private static final long serialVersionUID = 1L;

   public DBRollbackException()
   {
      super();
   }

   public DBRollbackException(String message, Throwable cause)
   {
      super(message, cause);
   }

   public DBRollbackException(String message)
   {
      super(message);
   }

   public DBRollbackException(Throwable cause)
   {
      super(cause);
   }
}
