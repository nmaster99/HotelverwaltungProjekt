package ch.bbw.technicalexceptions;

public class DBCommitException extends TechnicalException {

	private static final long serialVersionUID = 1L;

	public DBCommitException()
	{
		super();
	}
	
	public DBCommitException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public DBCommitException(String message)
	{
		super(message);
	}
	
	public DBCommitException(Throwable cause)
	{
		super(cause);
	}
}
