package ch.bbw.technicalexceptions;

public class DBDriverException extends TechnicalException {

	private static final long serialVersionUID = 1L;

	public DBDriverException()
	{
		super();
	}
	
	public DBDriverException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	public DBDriverException(String message)
	{
		super(message);
	}
	
	public DBDriverException(Throwable cause)
	{
		super(cause);
	}
}
