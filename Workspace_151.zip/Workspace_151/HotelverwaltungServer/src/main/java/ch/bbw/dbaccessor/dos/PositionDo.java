package ch.bbw.dbaccessor.dos;

import java.sql.Date;

public class PositionDo extends Do{
	
	private Integer id;
	private Integer booking_idfs;
	private Integer service_idfs;
	private Integer user_idfs;
	private Integer quantity;
	private double price;
	private double discount;
	private Date date; 
	
	public PositionDo() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getBooking_idfs() {
		return booking_idfs;
	}

	public void setBooking_idfs(Integer booking_idfs) {
		this.booking_idfs = booking_idfs;
	}

	public Integer getService_idfs() {
		return service_idfs;
	}

	public void setService_idfs(Integer service_idfs) {
		this.service_idfs = service_idfs;
	}

	public Integer getUser_idfs() {
		return user_idfs;
	}

	public void setUser_idfs(Integer user_idfs) {
		this.user_idfs = user_idfs;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
