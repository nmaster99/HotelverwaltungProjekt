package ch.bbw.dbaccessor.dos;

import java.sql.Date;

public class BookingDo extends Do{
	
	private Integer id;
	private Integer person_idfs;
	private Date arrivalDate;
	private Date departurDate;
	
	public BookingDo(){
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getPerson_idfs() {
		return person_idfs;
	}

	public void setPerson_idfs(Integer person_idfs) {
		this.person_idfs = person_idfs;
	}

	public Date getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}

	public Date getDeparturDate() {
		return departurDate;
	}

	public void setDeparturDate(Date departurDate) {
		this.departurDate = departurDate;
	}
}
