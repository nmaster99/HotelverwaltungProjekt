package ch.bbw.usermanager;

import java.util.List;

import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;

public interface IUserManager {
	
	/*
	 * Gibt Liste aller Mitarbeiter zurrück
	 */
	public List<UserRo> getUsers(); 
	
	/*
	 * Lädt alle Käufe unter dieser Person
	 */
	public List<Position> getPositionsByUserId(Integer id);
	
	/*
	 * Total des jeweiligen Kaufes
	 */
	public Double getTotalOfPositionByPositionId(Integer id);
}
