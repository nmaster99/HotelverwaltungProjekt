package ch.bbw.model.ro;

import java.util.List;

import ch.bbw.model.bo.Position;

public class ServiceRo extends Ro{
	
	private Integer id;
	private String description;
	private List<Position> positions;
	
	public ServiceRo() {
		
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<Position> getPositions() {
		return positions;
	}

	public void setPositions(List<Position> positions) {
		this.positions = positions;
	}
	
	
}
