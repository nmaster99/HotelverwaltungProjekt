package ch.bbw.dbaccessor;

import java.sql.ResultSet;
import java.sql.SQLException;

import ch.bbw.dbaccessor.dos.BookingDo;
import ch.bbw.dbaccessor.dos.Do;
import ch.bbw.dbaccessor.dos.PersonDo;
import ch.bbw.dbaccessor.dos.PositionDo;
import ch.bbw.dbaccessor.dos.UserRoDo;
import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.Ro;
import ch.bbw.model.ro.UserRo;

public class DatabaseConverter {
	
	public static UserRoDo convertUserResultSetToDo(ResultSet rs) throws SQLException{
		
		UserRoDo userRoDo = new UserRoDo();
		userRoDo.setId(rs.getInt("Benutzer_ID"));
		userRoDo.setUsername(rs.getString("Benutzer"));
		userRoDo.setPassword(rs.getString("Passwort"));
		userRoDo.setName(rs.getString("GanzerName"));
		
		
		return userRoDo;
	}
	
	public static UserRo convertUserDoToRo(UserRoDo userRoDo) {
			
		UserRo userRo = new UserRo();
		userRo.setId(userRoDo.getId());
		userRo.setUsername(userRoDo.getUsername());
		userRo.setPassword(userRoDo.getPassword());
		userRo.setName(userRoDo.getName());

		return userRo;
	}
	
	public static PositionDo convertPositionResultSetToDo(ResultSet rs) throws SQLException{
		
		PositionDo positionDo = new PositionDo();
		positionDo.setId(rs.getInt("Position_ID"));
		positionDo.setBooking_idfs(rs.getInt("Buchung_IDFS"));
		positionDo.setService_idfs(rs.getInt("Leistung_IDFS"));
		positionDo.setUser_idfs(rs.getInt("Benutzer_IDFS"));
		positionDo.setQuantity(rs.getInt("Anzahl"));
		positionDo.setPrice(rs.getDouble("Preis"));
		positionDo.setDiscount(rs.getDouble("Rabatt"));
		positionDo.setDate(rs.getDate("Datum"));
			
		return positionDo;
	}
	
	public static Position convertPositionDoToBo(PositionDo positionDo){
		
		Position position = new Position();
		position.setId(positionDo.getId());
		position.setQuantity(positionDo.getQuantity());
		position.setPrice(positionDo.getPrice());
		position.setDiscount(positionDo.getDiscount());
		position.setDate(positionDo.getDate());
		
		return position;
	}
	
	public static PersonDo convertPersonResultSetToDo(ResultSet rs) throws SQLException{
		
		PersonDo personDo = new PersonDo();
		personDo.setId(rs.getInt("Person_ID"));
		personDo.setFirstName(rs.getString("Vorname"));
		personDo.setLastName(rs.getString("Name"));
		personDo.setStreetAdress(rs.getString("Strasse"));
		personDo.setCity(rs.getString("Ort"));
		personDo.setPhoneNumber(rs.getString("Privattelefon"));
		personDo.setEntryDate(rs.getDate("Eingabedatum"));
		
		return personDo;
	}
	
	public static Person convertPersonDoToBo(PersonDo personDo){
		
		Person person = new Person();
		person.setId(personDo.getId());
		person.setFirstName(personDo.getFirstName());
		person.setLastName(personDo.getLastName());
		person.setStreetAdress(personDo.getStreetAdress());
		person.setCity(personDo.getCity());
		person.setPhoneNumber(personDo.getPhoneNumber());
		person.setEntryDate(personDo.getEntryDate());
		
		return person;
	}
	
	public static BookingDo convertBookingResultSetToDo(ResultSet rs) throws SQLException{
		
		BookingDo bookingDo = new BookingDo();
		bookingDo.setId(rs.getInt("Buchung_ID"));
		bookingDo.setArrivalDate(rs.getDate("Ankunft"));
		bookingDo.setDeparturDate(rs.getDate("Abreise"));
		bookingDo.setPerson_idfs(rs.getInt("Person_IDFS"));
		
		return bookingDo;
	}
	
	public static Booking convertBookingDoToBo(BookingDo bookingDo){
		
		Booking booking = new Booking();
		booking.setId(bookingDo.getId());
		booking.setArrivalDate(bookingDo.getArrivalDate());
		booking.setDeparturDate(bookingDo.getDeparturDate());
	
		return booking;
	}
}
