package ch.bbw.personmanager;

import java.util.List;

import ch.bbw.model.bo.Booking;
import ch.bbw.model.bo.Person;

public class PersonManagerDelegator implements IPersonManager {
	private static PersonManagerDelegator instance;
	private PersonManager personManager;
	
	private PersonManagerDelegator() {
		personManager = new PersonManager();
	}

	public static IPersonManager getInstance() {
		if (instance == null) {
			instance = new PersonManagerDelegator();
		}
		return instance;
	}

	public List<Person> getPersonsByName(String name) {
		// TODO Auto-generated method stub
		return personManager.getPersonsByName(name);
	}

	public List<Person> getPersons() {
		// TODO Auto-generated method stub
		return personManager.getPersons();
	}

	public List<Booking> getPersonBookingsByUserId(Integer id) {
		// TODO Auto-generated method stub
		return personManager.getPersonBookingsByUserId(id);
	}
}
