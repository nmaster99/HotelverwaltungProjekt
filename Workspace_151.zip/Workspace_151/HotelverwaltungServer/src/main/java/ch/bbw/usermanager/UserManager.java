package ch.bbw.usermanager;

import java.util.ArrayList;
import java.util.List;

import ch.bbw.dbaccessor.DBAccessDelegator;
import ch.bbw.dbaccessor.MySQLUserDao;
import ch.bbw.model.bo.Position;
import ch.bbw.model.ro.UserRo;

public class UserManager implements IUserManager{

	public List<UserRo> getUsers() {
		// TODO Auto-generated method stub
		//In die DO Schicht
		return DBAccessDelegator.getInstance().getUsers();
	}

	public List<Position> getPositionsByUserId(Integer id) {
		// TODO Auto-generated method stub
		//In die DO Schicht
		return DBAccessDelegator.getInstance().getPositionsByUserId(id);
	}
	
	public Double getTotalOfPositionByPositionId(Integer id) {
		// TODO Auto-generated method stub
		Double total = 0.00;
		List <Position> positions = new ArrayList<Position>();
		positions = DBAccessDelegator.getInstance().getPositionsByUserId(id);
		System.out.println(id);
		for(Position position : positions){
			total =  total + (position.getQuantity() * (position.getPrice() - position.getDiscount()));
		}
		
		return total;
	}

}
